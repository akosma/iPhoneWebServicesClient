//
//  BSJSONScanner_UnitTests.h
//
//  History:
//
//	2006 Mar 24 garrison@standardorbit.net
//
//	Adapted from Jonathan Wight's CJSONScanner_UnitTests by Bill Garrison.

#import <SenTestingKit/SenTestingKit.h>


@interface BSJSONScanner_UnitTests : SenTestCase
{
	NSScanner *theScanner;
}

@end
