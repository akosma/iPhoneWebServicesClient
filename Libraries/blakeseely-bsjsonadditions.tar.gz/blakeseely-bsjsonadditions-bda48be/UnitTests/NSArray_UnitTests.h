//
//  NSArray_UnitTests.h
//  BSJSONAdditions
//
//  Created by Blake Seely (Air) on 3/24/09.
//  Copyright 2009 Apple Inc.. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>


@interface NSArray_UnitTests : SenTestCase

@end
