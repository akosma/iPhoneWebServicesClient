//
//  JSONValidTests.h
//  BSJSONAdditions
//
//  Created by Blake Seely on 2/2/06.
//  Copyright 2006 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>


@interface JSONValidTests : SenTestCase {

}

@end
