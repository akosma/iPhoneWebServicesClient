//
//  NSString_UnitTests.h
//  BSJSONAdditions
//

#import <SenTestingKit/SenTestingKit.h>

@interface NSString_UnitTests : SenTestCase

@end
