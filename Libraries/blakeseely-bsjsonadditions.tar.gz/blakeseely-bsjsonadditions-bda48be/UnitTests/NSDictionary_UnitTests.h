//
//  NSDictionary_UnitTests.h
//  BSJSONAdditions
//

#import <SenTestingKit/SenTestingKit.h>

@interface NSDictionary_UnitTests : SenTestCase

@end
