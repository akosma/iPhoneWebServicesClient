#import <Cocoa/Cocoa.h>


@interface DDXMLTesting : NSObject

+ (void)performTests;

@end
