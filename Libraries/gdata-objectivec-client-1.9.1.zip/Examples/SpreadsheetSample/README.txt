This sample should automatically build and copy over the GData.framework as part of the build-and-run process.

The Spreadsheet list and cell APIs will likely eventually be replaced with the tables &
records API, as demonstrated in the SpreadsheetTableSample example application.
