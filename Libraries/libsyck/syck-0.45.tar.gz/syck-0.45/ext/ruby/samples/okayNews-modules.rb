
require 'okay/news'

p YAML::load( DATA )

__END__
--- %YAML:1.0 !okay/news
title: whytheluckystiff.net
link: http://www.whytheluckystiff.net/
description: Home remedies for braindeath.
updatePeriod: 01:00:00
items:
  - !okay/news/item
    pubTime: 2002-10-23T09:03:40.00-06:00 
    link: http://whytheluckystiff.net/arch/2002/10/23#1035385420 
    dc;test: 1
    description: >
      Considering the
      "discussion"="http://philringnalda.com/archives/002359.php"

  - !okay/news/item
    pubTime: 2002-10-22T23:46:57.00-06:00 
    link: http://whytheluckystiff.net/arch/2002/10/22#1035352017 
    dc;test: 1
    description: >
      Last night I hung out at this hotel with my relatives, all
      in town to see
